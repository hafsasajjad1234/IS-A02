<?php require_once 'db.php'; require_once 'includes/header.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';

    if (is_safe()) {
        // ---- SAFE: parameterized query ----
        $stmt = $conn->prepare("SELECT id,username,role FROM users WHERE username=? AND password=?");
        $stmt->bind_param("ss", $u, $p);
        $stmt->execute();
        $res = $stmt->get_result();
    } else {
        // ---- VULNERABLE: string-concatenated query (SQL INJECTION) ----
        $sql = "SELECT id,username,role FROM users WHERE username='$u' AND password='$p'";
        echo '<div class="card"><small>Executed query:<br><code>'.htmlspecialchars($sql).'</code></small></div>';
        $res = $conn->query($sql);
    }

    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $_SESSION['user'] = $row['username'];
        $_SESSION['role'] = $row['role'] ?? 'user';
        $msg = '<p style="color:green">Login successful! Welcome '.htmlspecialchars($row['username']).'.</p>';
    } else {
        $msg = '<p style="color:#b12704">Invalid credentials.</p>';
    }
}
?>
<div class="card" style="max-width:380px">
  <h2>Login</h2>
  <?php echo $msg; ?>
  <form method="POST" action="login.php">
    <input type="text" name="username" placeholder="Username"><br>
    <input type="password" name="password" placeholder="Password"><br>
    <button type="submit">Login</button>
  </form>
  <small>Test user: alice / password1</small>
</div>
<?php require_once 'includes/footer.php'; ?>
