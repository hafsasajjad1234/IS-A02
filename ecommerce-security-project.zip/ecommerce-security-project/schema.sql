-- Run:  sudo mysql < schema.sql
DROP DATABASE IF EXISTS shop_security;
CREATE DATABASE shop_security;
USE shop_security;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(100) NOT NULL,   -- plaintext ON PURPOSE (vuln demo); safe note in README
  email VARCHAR(100) NOT NULL,
  role VARCHAR(20) DEFAULT 'user'
);

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price DECIMAL(10,2),
  image VARCHAR(100)
);

CREATE TABLE reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT,
  author VARCHAR(50),
  comment TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO users (username, password, email, role) VALUES
('admin', 'admin123', 'admin@shop.com', 'admin'),
('alice', 'password1', 'alice@mail.com', 'user'),
('bob',   'qwerty',    'bob@mail.com',   'user');

INSERT INTO products (name, description, price, image) VALUES
('Wireless Headphones', 'Noise-cancelling over-ear headphones.', 59.99, 'hp.png'),
('Mechanical Keyboard', 'RGB hot-swap mechanical keyboard.',     89.99, 'kb.png'),
('USB-C Charger',       '65W fast GaN charger.',                 24.99, 'ch.png'),
('Laptop Stand',        'Aluminium adjustable stand.',           34.99, 'ls.png');

INSERT INTO reviews (product_id, author, comment) VALUES
(1, 'alice', 'Great sound quality!'),
(1, 'bob',   'Comfortable for long use.');
