<?php require_once 'db.php'; require_once 'includes/header.php'; ?>

<div class="card">
  <h2>Search products</h2>
  <form method="GET" action="index.php">
    <input type="text" name="q" placeholder="Search..." value="<?php
        // ---- REFLECTED XSS ----
        if (isset($_GET['q'])) {
            if (is_safe()) echo htmlspecialchars($_GET['q'], ENT_QUOTES);
            else           echo $_GET['q'];          // VULNERABLE: raw reflection
        }
    ?>">
    <button type="submit">Search</button>
  </form>
  <?php if (isset($_GET['q'])): ?>
    <p>Showing results for:
      <?php
        // ---- REFLECTED XSS (also echoed in page body) ----
        if (is_safe()) echo htmlspecialchars($_GET['q'], ENT_QUOTES);
        else           echo $_GET['q'];              // VULNERABLE
      ?>
    </p>
  <?php endif; ?>
</div>

<div class="card">
  <h2>Products</h2>
  <div class="grid">
  <?php
    $q = isset($_GET['q']) ? $_GET['q'] : '';
    // product search uses a prepared statement in BOTH modes (SQLi is demoed on product.php & login.php)
    $stmt = $conn->prepare("SELECT id,name,description,price FROM products WHERE name LIKE ?");
    $like = "%$q%"; $stmt->bind_param("s", $like); $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        echo '<div class="card">';
        echo '<h3>'.htmlspecialchars($row['name']).'</h3>';
        echo '<p>'.htmlspecialchars($row['description']).'</p>';
        echo '<p class="price">$'.htmlspecialchars($row['price']).'</p>';
        echo '<a href="product.php?id='.$row['id'].'">View &amp; reviews</a>';
        echo '</div>';
    }
  ?>
  </div>
</div>
<?php require_once 'includes/footer.php'; ?>
