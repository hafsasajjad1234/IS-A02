# SecureShop — Web Security Demo (IS Assignment 2, Part 2)

A small **e-commerce** web app that demonstrates common web vulnerabilities **and** their fixes.
The **same codebase** runs in two modes, switched by **one line** in `config.php`:

```php
define('MODE', 'vulnerable');   // all attacks work
// define('MODE', 'safe');      // all attacks blocked
```

## Tech stack
- PHP (backend)
- MySQL / MariaDB (database)
- Plain HTML/CSS frontend

## Vulnerabilities implemented (vulnerable mode) & fixes (safe mode)
| # | Vulnerability | Where | Fix in safe mode |
|---|---------------|-------|------------------|
| 1 | Reflected XSS | `index.php` search `?q=` | `htmlspecialchars()` output encoding |
| 2 | Stored XSS | `product.php` reviews | `htmlspecialchars()` on output |
| 3 | DOM-based XSS | `dom.php` (`location.hash`) | `textContent` instead of `innerHTML` |
| 4 | CSRF | `profile.php` change-email | per-session CSRF token (`includes/csrf.php`) |
| 5 | SQLi (easy) | `login.php` login bypass | prepared statement |
| 6 | SQLi (intermediate) | `product.php?id=` blind/error-based | `intval()` + prepared statement |
| 7 | SQLi (advanced) | `product.php?id=` UNION chain | `intval()` + prepared statement |

## How to run (Kali / Ubuntu)
```bash
# 1) Start MySQL/MariaDB
sudo service mysql start        # or: sudo service mariadb start

# 2) Import the database + seed data
sudo mysql < schema.sql

# 3) (if needed) set DB creds in config.php  (DB_USER / DB_PASS)

# 4) Start the app from the project folder
php -S localhost:8000

# 5) Open in browser
#    http://localhost:8000/index.php
```

## Switching versions
- **Vulnerable:** `config.php` -> `define('MODE','vulnerable');`
- **Safe:** `config.php` -> `define('MODE','safe');`
Reload the page — the red/green badge in the header shows the current mode.

## Test accounts
| username | password |
|----------|----------|
| admin | admin123 |
| alice | password1 |
| bob   | qwerty   |

## Notes for graders
- Passwords are stored in plaintext **on purpose** to make the SQLi data-exfiltration demo clear.
  In a real app they would be hashed with `password_hash()` (bcrypt). See the safe-mode discussion in the report.
- All attack payloads and screenshots are documented in `PAYLOADS.md` and in the Word report.
