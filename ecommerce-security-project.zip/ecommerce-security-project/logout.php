<?php require_once 'includes/header.php'; session_destroy();
echo '<div class="card">You have been logged out. <a href="index.php">Home</a></div>';
require_once 'includes/footer.php'; ?>
