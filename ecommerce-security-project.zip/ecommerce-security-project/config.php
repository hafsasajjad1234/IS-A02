<?php
/* =========================================================
   SINGLE TOGGLE for the whole project.
   Change this one line to switch the entire app:
     'vulnerable'  -> all attacks work
     'safe'        -> all attacks are blocked
   ========================================================= */
define('MODE', 'vulnerable');   // <-- change to 'safe' for the hardened version

/* ---- Database settings (edit if your MySQL/MariaDB differs) ---- */
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');          // Kali MariaDB default is often empty
define('DB_NAME', 'shop_security');

function is_safe() { return MODE === 'safe'; }
