<?php require_once 'includes/header.php'; ?>
<div class="card">
  <h2>Today's Deal</h2>
  <p>Deal code (from URL after #):</p>
  <div id="output" style="padding:10px;background:#fafafa;border:1px solid #eee">(none)</div>
</div>
<script>
  // Reads untrusted data from the URL fragment (never sent to server)
  var frag = decodeURIComponent(location.hash.substring(1));
  var out = document.getElementById('output');
  var SAFE = <?php echo is_safe() ? 'true':'false'; ?>;
  if (frag) {
    if (SAFE) {
      out.textContent = frag;   // SAFE: textContent does not parse HTML
    } else {
      out.innerHTML = frag;     // VULNERABLE: DOM-based XSS via innerHTML
    }
  }
</script>
<?php require_once 'includes/footer.php'; ?>
