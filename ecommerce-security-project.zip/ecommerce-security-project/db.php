<?php
require_once __DIR__ . '/config.php';
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("DB connection failed: " . $conn->connect_error .
        "<br>Did you import schema.sql and set creds in config.php?");
}
?>
