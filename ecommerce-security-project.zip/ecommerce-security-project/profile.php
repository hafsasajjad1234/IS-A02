<?php require_once 'db.php'; require_once 'includes/csrf.php'; require_once 'includes/header.php';
if (empty($_SESSION['user'])) { echo '<div class="card">Please <a href="login.php">login</a> first.</div>'; require_once 'includes/footer.php'; exit; }

$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['email'])) {
    csrf_check();  // only enforced in SAFE mode
    $email = $_POST['email'];
    $user  = $_SESSION['user'];
    $stmt = $conn->prepare("UPDATE users SET email=? WHERE username=?");
    $stmt->bind_param("ss", $email, $user); $stmt->execute();
    $msg = '<p style="color:green">Email updated to '.htmlspecialchars($email).'</p>';
}
// show current email
$u=$_SESSION['user'];
$st=$conn->prepare("SELECT email FROM users WHERE username=?"); $st->bind_param("s",$u); $st->execute();
$cur=$st->get_result()->fetch_assoc();
?>
<div class="card" style="max-width:420px">
  <h2>My Profile</h2>
  <p>User: <b><?php echo htmlspecialchars($u);?></b></p>
  <p>Current email: <b><?php echo htmlspecialchars($cur['email']??'');?></b></p>
  <?php echo $msg; ?>
  <h3>Change email</h3>
  <!-- This is the STATE-CHANGING action targeted by CSRF -->
  <form method="POST" action="profile.php">
    <?php echo csrf_field(); // empty in vulnerable mode, token in safe mode ?>
    <input type="email" name="email" placeholder="new@email.com" required>
    <button type="submit">Update email</button>
  </form>
</div>
<?php require_once 'includes/footer.php'; ?>
