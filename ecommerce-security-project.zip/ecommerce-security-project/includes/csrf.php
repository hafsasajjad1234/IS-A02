<?php
/* CSRF helpers - only enforced in SAFE mode */
if (session_status()===PHP_SESSION_NONE) session_start();

function csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field() {
    // In vulnerable mode we output NOTHING -> no token protects the form
    if (is_safe()) {
        return '<input type="hidden" name="csrf" value="'.csrf_token().'">';
    }
    return '';
}

function csrf_check() {
    if (!is_safe()) return true; // vulnerable mode: never validates
    $ok = isset($_POST['csrf']) && hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf']);
    if (!$ok) { http_response_code(403); die('CSRF token missing/invalid - request blocked (SAFE mode).'); }
    return true;
}
