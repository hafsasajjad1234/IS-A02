</div>
<footer style="text-align:center;color:#888;padding:20px;font-size:12px">
  SecureShop demo &mdash; IS Assignment 2 Part 2 &mdash; current mode: <b><?php echo MODE; ?></b>
</footer>
</body>
</html>
