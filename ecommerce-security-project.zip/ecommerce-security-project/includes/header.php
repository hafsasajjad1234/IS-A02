<?php require_once __DIR__ . '/../config.php'; if (session_status()===PHP_SESSION_NONE) session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SecureShop (<?php echo MODE; ?> mode)</title>
<style>
  body{font-family:Arial,Helvetica,sans-serif;margin:0;background:#f4f4f4;color:#222}
  header{background:#232f3e;color:#fff;padding:12px 20px;display:flex;justify-content:space-between;align-items:center}
  header a{color:#fff;text-decoration:none;margin-left:16px}
  .mode{font-size:12px;padding:3px 8px;border-radius:4px;background:<?php echo is_safe()?'#1b7f37':'#b12704';?>}
  .wrap{max-width:1000px;margin:20px auto;padding:0 16px}
  .card{background:#fff;border:1px solid #ddd;border-radius:6px;padding:16px;margin-bottom:16px}
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:16px}
  input,textarea,button{padding:8px;font-size:14px;margin:4px 0}
  button{background:#febd69;border:none;border-radius:4px;cursor:pointer}
  .price{color:#b12704;font-weight:bold}
  nav form{display:inline}
</style>
</head>
<body>
<header>
  <div><a href="index.php"><b>SecureShop</b></a></div>
  <nav>
    <a href="index.php">Home</a>
    <a href="dom.php">Deals</a>
    <a href="profile.php">Profile</a>
    <?php if(!empty($_SESSION['user'])): ?>
      <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['user']); ?>)</a>
    <?php else: ?>
      <a href="login.php">Login</a>
    <?php endif; ?>
    <span class="mode">MODE: <?php echo strtoupper(MODE); ?></span>
  </nav>
</header>
<div class="wrap">
