<?php require_once 'db.php'; require_once 'includes/header.php';
$id = isset($_GET['id']) ? $_GET['id'] : '1';

// ----- fetch product: VULNERABLE id param (boolean-blind + error-based + UNION) -----
if (is_safe()) {
    $id = intval($id);                                   // SAFE: force integer
    $stmt = $conn->prepare("SELECT id,name,description,price FROM products WHERE id=?");
    $stmt->bind_param("i", $id); $stmt->execute();
    $res = $stmt->get_result();
} else {
    $sql = "SELECT id,name,description,price FROM products WHERE id=$id"; // VULNERABLE
    echo '<div class="card"><small>Executed query:<br><code>'.htmlspecialchars($sql).'</code></small></div>';
    $res = $conn->query($sql);
    if (!$res) echo '<div class="card" style="color:#b12704">SQL error: '.$conn->error.'</div>'; // error-based leak
}

if ($res && $row = $res->fetch_assoc()) {
    echo '<div class="card"><h2>'.htmlspecialchars($row['name']).'</h2>';
    echo '<p>'.htmlspecialchars($row['description']).'</p>';
    echo '<p class="price">$'.htmlspecialchars($row['price']).'</p></div>';
}

// ----- post a review -----
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['comment'])) {
    $author  = $_SESSION['user'] ?? 'guest';
    $comment = $_POST['comment'];
    $pid = intval($_GET['id'] ?? 1);
    // storage uses prepared stmt (so SQLi isn't the point here); XSS is about OUTPUT encoding
    $stmt = $conn->prepare("INSERT INTO reviews (product_id,author,comment) VALUES (?,?,?)");
    $stmt->bind_param("iss", $pid, $author, $comment); $stmt->execute();
    echo '<div class="card" style="color:green">Review added.</div>';
}

// ----- list reviews: STORED XSS on output -----
echo '<div class="card"><h3>Reviews</h3>';
$pid = intval($_GET['id'] ?? 1);
$rs = $conn->query("SELECT author,comment,created_at FROM reviews WHERE product_id=$pid ORDER BY id DESC");
while ($rs && $rv = $rs->fetch_assoc()) {
    echo '<div style="border-bottom:1px solid #eee;padding:6px 0">';
    echo '<b>'.htmlspecialchars($rv['author']).'</b>: ';
    // ---- STORED XSS ----
    if (is_safe()) echo htmlspecialchars($rv['comment'], ENT_QUOTES); // SAFE: encoded output
    else           echo $rv['comment'];                               // VULNERABLE: raw output
    echo ' <small style="color:#999">'.$rv['created_at'].'</small></div>';
}
echo '</div>';
?>
<div class="card">
  <h3>Add a review</h3>
  <form method="POST" action="product.php?id=<?php echo intval($id);?>">
    <textarea name="comment" rows="3" cols="50" placeholder="Write a review..."></textarea><br>
    <button type="submit">Submit review</button>
  </form>
</div>
<?php require_once 'includes/footer.php'; ?>
